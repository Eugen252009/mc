const fs = require('fs');

const folder = 'functions/new'
const max = 19

for (let i = 0; i <= max; i++) {

    const fileName = `${i}.mcfunction`
    const path = `${folder}/${fileName}`

    // build list
    /*
    let content = `data modify storage pns:data root.players[-1].${i} set from storage pns:temp root.array[0]
    execute unless data storage pns:temp root.array[] run data modify storage pns:data root.players[-1].${i} set value 0
    data remove storage pns:temp root.array[0]
`
*/
    let content = `scoreboard players operation #pns.bit dummy = #pns.value dummy
    execute store result storage pns:temp root.new.${i} int 1 run scoreboard players operation #pns.bit dummy %= #3 dummy
    scoreboard players operation #pns.value dummy /= #3 dummy
`
    if (i!=max) content += `    function pns:new/${i+1}
`
    
    // Generate folders
    if (!fs.existsSync(folder)) fs.mkdirSync(folder);
    //if (!fs.existsSync(dir)) fs.mkdirSync(dir);
    // Write Json File
    fs.writeFileSync(path, content)
    // Confirm Output
}