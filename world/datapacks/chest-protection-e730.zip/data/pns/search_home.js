const fs = require('fs');

const folder = 'functions/search/home'
const max = 19

for (let i = 0; i <= max; i++) {

    const fileName = `${i}.mcfunction`
    const path = `${folder}/${fileName}`

    // build list
    let content = `scoreboard players operation #pns.home.bit dummy = #pns.home.value dummy
    scoreboard players operation #pns.home.bit dummy %= #3 dummy
        execute if score #pns.home.bit dummy matches 0 run data modify storage pns:temp root.home.filtered${i} append from storage pns:data root.result.Home[{${i}:0}]
        execute if score #pns.home.bit dummy matches 0 run data modify storage pns:temp root.home.leftover append from storage pns:data root.result.Home[{${i}:1}]
        execute if score #pns.home.bit dummy matches 0 run data modify storage pns:temp root.home.leftover append from storage pns:data root.result.Home[{${i}:2}]
        execute if score #pns.home.bit dummy matches 1 run data modify storage pns:temp root.home.filtered${i} append from storage pns:data root.result.Home[{${i}:1}]
        execute if score #pns.home.bit dummy matches 1 run data modify storage pns:temp root.home.leftover append from storage pns:data root.result.Home[{${i}:0}]
        execute if score #pns.home.bit dummy matches 1 run data modify storage pns:temp root.home.leftover append from storage pns:data root.result.Home[{${i}:2}]
        execute if score #pns.home.bit dummy matches 2 run data modify storage pns:temp root.home.filtered${i} append from storage pns:data root.result.Home[{${i}:2}]
        execute if score #pns.home.bit dummy matches 2 run data modify storage pns:temp root.home.leftover append from storage pns:data root.result.Home[{${i}:0}]
        execute if score #pns.home.bit dummy matches 2 run data modify storage pns:temp root.home.leftover append from storage pns:data root.result.Home[{${i}:1}]
    scoreboard players operation #pns.home.value dummy /= #3 dummy
    
    execute store result score #pns.size dummy if data storage pns:temp root.home.filtered${i}[]
        #execute if score #pns.size dummy matches 0 run function pns:new/main
        execute if score #pns.size dummy matches 0..1 run data modify storage pns:temp root.home.result set from storage pns:temp root.home.filtered${i}[0]
`
        if (i!=max) content += `        execute if score #pns.size dummy matches 2.. run function pns:search/home/${i+1}
    `
    
    // Generate folders
    if (!fs.existsSync(folder)) fs.mkdirSync(folder);
    //if (!fs.existsSync(dir)) fs.mkdirSync(dir);
    // Write Json File
    fs.writeFileSync(path, content)
}