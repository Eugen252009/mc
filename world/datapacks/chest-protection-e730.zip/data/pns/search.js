const fs = require('fs');

const folder = 'functions/search'
const max = 19
const empty = ""

for (let i = 0; i <= max; i++) {

    const fileName = `${i}.mcfunction`
    const path = `${folder}/${fileName}`

    // build list
    let content = `scoreboard players operation #pns.bit dummy = #pns.value dummy
    scoreboard players operation #pns.bit dummy %= #3 dummy
        execute if score #pns.bit dummy matches 0 run data modify storage pns:temp root.array${i} append from storage pns:temp root.array${i-1>=0?i-1:empty}[{${i}:0}]
        execute if score #pns.bit dummy matches 0 run data modify storage pns:temp root.leftover append from storage pns:temp root.array${i-1>=0?i-1:empty}[{${i}:1}]
        execute if score #pns.bit dummy matches 0 run data modify storage pns:temp root.leftover append from storage pns:temp root.array${i-1>=0?i-1:empty}[{${i}:2}]
        execute if score #pns.bit dummy matches 1 run data modify storage pns:temp root.array${i} append from storage pns:temp root.array${i-1>=0?i-1:empty}[{${i}:1}]
        execute if score #pns.bit dummy matches 1 run data modify storage pns:temp root.leftover append from storage pns:temp root.array${i-1>=0?i-1:empty}[{${i}:0}]
        execute if score #pns.bit dummy matches 1 run data modify storage pns:temp root.leftover append from storage pns:temp root.array${i-1>=0?i-1:empty}[{${i}:2}]
        execute if score #pns.bit dummy matches 2 run data modify storage pns:temp root.array${i} append from storage pns:temp root.array${i-1>=0?i-1:empty}[{${i}:2}]
        execute if score #pns.bit dummy matches 2 run data modify storage pns:temp root.leftover append from storage pns:temp root.array${i-1>=0?i-1:empty}[{${i}:0}]
        execute if score #pns.bit dummy matches 2 run data modify storage pns:temp root.leftover append from storage pns:temp root.array${i-1>=0?i-1:empty}[{${i}:1}]
    scoreboard players operation #pns.value dummy /= #3 dummy
    
    execute store result score #pns.size dummy if data storage pns:temp root.array${i}[]
        execute if score #pns.size dummy matches 0..1 run data modify storage pns:search root.result set from storage pns:temp root.array${i}[0]
`
        if (i!=max) content += `        execute if score #pns.size dummy matches 2.. run function pns:search/${i+1}
    `
    
    // Generate folders
    if (!fs.existsSync(folder)) fs.mkdirSync(folder);
    //if (!fs.existsSync(dir)) fs.mkdirSync(dir);
    // Write Json File
    fs.writeFileSync(path, content)
}